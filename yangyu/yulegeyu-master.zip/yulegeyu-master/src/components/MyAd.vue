<template>
  <div class="my-ad">
    <a href="https://github.com/liyupi/yulegeyu" target="_blank">
      <div style="background: rgba(0, 0, 0, 0.8); padding: 12px">
        <github-outlined />
        代码完全开源，欢迎 star
      </div>
    </a>
    <!-- <a href="https://space.bilibili.com/12890453/"> 欢迎关注程序员鱼皮 </a>-->
  </div>
</template>
<script setup lang="ts">
import { GithubOutlined } from "@ant-design/icons-vue";
</script>
<style></style>
